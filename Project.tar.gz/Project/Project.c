#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void)
{
    char line[1024];
    char working_dir[1024];
    char buffer[512];
    char RightArrow[] = ">";
    char TwoRightArrow[] = ">>";
    char reverse_read[50][1024];
    char charFile;          // used to print char by char from file
    FILE *infile, *outfile; // files pointers to read and write
    int i, limit;                  // used as a counter
    DIR *mydir;
    struct dirent *pointer;
    struct stat mystat;
    printf("\nRoot: ");
    while (fgets(line, sizeof(line), stdin) != NULL)
    {
        if (strcmp(line, "exit\n") == 0)
            exit(EXIT_SUCCESS);

        char *args[64];
        char **next = args;
        char *temp = strtok(line, " \n");
        int ArgumentsNumber = 0;
        while (temp != NULL)
        {
            ArgumentsNumber++;
            *next++ = temp;
            temp = strtok(NULL, " \n");
        }
        // printf("number of arguments: %d \n", ArgumentsNumber);
        *next = NULL;
        if(args[0] == NULL){
        // do nothing
        }
        else if (strcmp(args[0], "mycat") == 0)
        {
            /* 
            cat
            cat file1 file2 file3
            cat file >> file2
            cat file > file2
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber < 2)
                printf("Incorrect Command! \n");
            else if ((ArgumentsNumber == 4) && ((strcmp(args[2], RightArrow) == 0) || (strcmp(args[2], TwoRightArrow) == 0)))
            {
                infile = fopen(args[1], "r");
                if (!strcmp(args[2], RightArrow))
                    outfile = fopen(args[3], "w");
                else
                    outfile = fopen(args[3], "a");
                if ((infile == NULL) || (outfile == NULL))
                {
                    printf("Cannot open file \n");
                    exit(1);
                }
                //if (!strcmp(args[2], TwoRightArrow))
                //fputc('\n', outfile);
                charFile = fgetc(infile);
                while (charFile != EOF)
                {
                    fputc(charFile, outfile);
                    charFile = fgetc(infile);
                }
                fclose(infile);
                fclose(outfile);
            }
            else
            {
                for (i = 1; i < ArgumentsNumber; i++)
                {
                    infile = fopen(args[i], "r");
                    if (infile == NULL)
                    {
                        printf("Error: Failed to open file. Enter correct name!\n");
                        exit(1);
                    }
                    charFile = fgetc(infile);
                    while (charFile != EOF)
                    {
                        printf("%c", charFile);
                        charFile = fgetc(infile);
                    }
                    fclose(infile);
                }
            }
        }
        else if (strcmp(args[0], "myls") == 0)
        {
            /* 
            ls
            ls [dir]
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (((ArgumentsNumber == 1) || (ArgumentsNumber == 2)) && strcmp(args[0], "ls"))
            {
                if(ArgumentsNumber == 1)
                strcpy(working_dir, ".");
                else
                strcpy(working_dir, args[1]);
                mydir = opendir(working_dir);
                while ((pointer = readdir(mydir)) != NULL)
                {
                    if (strcmp(pointer->d_name, ".") != 0 && strcmp(pointer->d_name, "..") != 0 && pointer->d_name[0] != '.') //don't print names of hidden files
                        printf("%s\t", pointer->d_name);
                }
                closedir(mydir);
            }  
                    printf("\n");
        }
        else if (strcmp(args[0], "myclear") == 0)
        {
            /* 
            myclear
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 1)
                printf("Wrong Command!");
            else
                system("clear"); // or printf("\e[1;1H\e[2J");
        }
        else if (strcmp(args[0], "mycp") == 0)
        {
            /* 
            cp
            cp path1 path2
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 3)
                printf("Incorrect Command! \n");
            else
            {
                infile = fopen(args[1], "r");
                outfile = fopen(args[2], "w");
                if ((infile == NULL) || (outfile == NULL))
                {
                    printf("Cannot open file \n");
                    exit(1);
                }
                charFile = fgetc(infile);
                while (charFile != EOF)
                {
                    fputc(charFile, outfile);
                    charFile = fgetc(infile);
                }
                fclose(infile);
                fclose(outfile);
            }
        }
        else if (strcmp(args[0], "mymv") == 0)
        {
            /* 
            mv path1 path2
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 3)
                printf("Wrong Command!");
            else
            {
                link(args[1], args[2]);
                unlink(args[1]);
            }
        }
        else if (strcmp(args[0], "myrm") == 0)
        {
            /* 
            myrm path1 path2
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 2)
                printf("Wrong Command!");
            else
            {
                unlink(args[1]);
            }
        }
        else if ((strcmp(args[0], "mycd") == 0) || (strcmp(args[0], "cd") == 0))
        {
            /* 
            cd path
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 2)
                printf("Wrong Command!");
            else
            {
                if (!chdir(args[1]))
                {
                    getcwd(working_dir, sizeof(working_dir));
                    printf("%s", working_dir);
                }
                else
                {
                    printf("Error!");
                }
            }
                    printf("\n");
        }
        else if (strcmp(args[0], "mymkdir") == 0)
        {
            /* 
            mymkdir path
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 2)
                printf("Wrong Command!");
            else
            {
                mkdir(args[1], 0775);
            }
        }
        else if (strcmp(args[0], "mypwd") == 0)
        {
            /* 
            mypwd
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 1)
                printf("Wrong Command!");
            else{
            getcwd(working_dir, sizeof(working_dir));
            printf("%s", working_dir);
            }
                    printf("\n");
        }
        else if (strcmp(args[0], "myhead") == 0)
        {
            /* 
            head
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 2)
                printf("Wrong Command!");
            else{
                infile = fopen(args[1], "r");
                i = 0;
                if (infile == NULL){
                printf("Could not open file %s", args[1]);
                return 1;
                }                
                while (fgets(buffer, sizeof(buffer), infile) != NULL){
                    fputs(buffer, stdout);
                    i++;
                    if(i == 10)
                    break;  
                }
                fclose(infile);
            }
        }
        else if (strcmp(args[0], "mytail") == 0)
        {
            /* 
            tail
#########################################################
#########################################################
#########################################################
#########################################################
#########################################################
            */
            if (ArgumentsNumber != 2)
                printf("Wrong Command!");
            else{
                infile = fopen(args[1], "r");
                i = 0;
                if (infile == NULL){
                printf("Could not open file %s", args[1]);
                return 1;
                }                
                while (fgets(buffer, sizeof(buffer), infile) != NULL){
                    strcpy(reverse_read[i], buffer);
                    i++;
                }
                limit = i;
                i=i-10;
                for(;i != limit;i++){
                fputs(reverse_read[i], stdout);
                }
                
                fclose(infile);
            }
        }
        else /* default: */
        {
            // fork and run as a child.
            pid_t pid;
            pid = fork();
            if(pid == 0){
            execvp(args[0], args);
            }
            else{
            wait(NULL);
            }
        }
    printf("Root: ");
    }

    return 1;
}
